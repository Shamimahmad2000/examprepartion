import { useEffect, useRef, useState } from "react";
import type { PDFDocumentProxy, RenderTask } from "pdfjs-dist";
import { Loader2, Minus, Plus } from "lucide-react";

type PdfJs = typeof import("pdfjs-dist");

/**
 * Renders a PDF with pdf.js onto canvases instead of Chrome's built-in viewer,
 * which is blocked when the file is served with a strict security policy.
 * Pages render only while near the visible area to keep phones fast.
 */
export function PdfViewer({ url }: { url: string }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [ratio, setRatio] = useState(1.414);
  const [error, setError] = useState<string | null>(null);
  const [width, setWidth] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [current, setCurrent] = useState(1);

  useEffect(() => {
    let cancelled = false;
    let loaded: PDFDocumentProxy | null = null;
    setDoc(null);
    setError(null);
    (async () => {
      try {
        const pdfjs: PdfJs = await import("pdfjs-dist/legacy/build/pdf.mjs");
        const workerUrl = (await import("pdfjs-dist/legacy/build/pdf.worker.min.mjs?url")).default;
        pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
        const task = pdfjs.getDocument({ url, disableAutoFetch: true, rangeChunkSize: 262144 });
        loaded = await task.promise;
        const first = await loaded.getPage(1);
        const vp = first.getViewport({ scale: 1 });
        if (cancelled) return;
        setRatio(vp.height / vp.width);
        setDoc(loaded);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "Could not load PDF");
      }
    })();
    return () => {
      cancelled = true;
      void loaded?.destroy();
    };
  }, [url]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth - 32));
    ro.observe(el);
    setWidth(el.clientWidth - 32);
    return () => ro.disconnect();
  }, []);

  const pageWidth = Math.max(200, Math.floor(width * zoom));

  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-card">
      <div className="flex items-center justify-between gap-3 border-b border-border bg-ink px-4 py-2 text-sm text-ink-foreground">
        <span>{doc ? `Page ${current} / ${doc.numPages}` : "Loading…"}</span>
        <div className="flex items-center gap-1">
          <button
            aria-label="Zoom out"
            className="rounded-md p-1.5 hover:bg-ink-foreground/10"
            onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.25).toFixed(2)))}
          >
            <Minus className="size-4" />
          </button>
          <span className="w-12 text-center tabular-nums">{Math.round(zoom * 100)}%</span>
          <button
            aria-label="Zoom in"
            className="rounded-md p-1.5 hover:bg-ink-foreground/10"
            onClick={() => setZoom((z) => Math.min(3, +(z + 0.25).toFixed(2)))}
          >
            <Plus className="size-4" />
          </button>
        </div>
      </div>
      <div ref={scrollRef} className="h-[80vh] overflow-auto bg-muted p-4">
        {error && <p className="py-20 text-center text-muted-foreground">Couldn't show the preview. Use “Open” or “Download PDF”.</p>}
        {!doc && !error && (
          <div className="grid h-full place-items-center text-muted-foreground">
            <Loader2 className="size-6 animate-spin" />
          </div>
        )}
        {doc && width > 0 && (
          <div className="mx-auto flex flex-col items-center gap-4" style={{ width: pageWidth }}>
            {Array.from({ length: doc.numPages }, (_, i) => (
              <PdfPage
                key={i}
                doc={doc}
                pageNumber={i + 1}
                width={pageWidth}
                height={Math.round(pageWidth * ratio)}
                root={scrollRef.current}
                onVisible={setCurrent}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PdfPage({
  doc,
  pageNumber,
  width,
  height,
  root,
  onVisible,
}: {
  doc: PDFDocumentProxy;
  pageNumber: number;
  width: number;
  height: number;
  root: HTMLElement | null;
  onVisible: (n: number) => void;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [near, setNear] = useState(false);
  const [pageHeight, setPageHeight] = useState(height);

  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const nearObs = new IntersectionObserver(([e]) => setNear(Boolean(e?.isIntersecting)), { root, rootMargin: "1200px 0px" });
    const seenObs = new IntersectionObserver(([e]) => e?.isIntersecting && onVisible(pageNumber), {
      root,
      threshold: 0.5,
    });
    nearObs.observe(el);
    seenObs.observe(el);
    return () => {
      nearObs.disconnect();
      seenObs.disconnect();
    };
  }, [root, pageNumber, onVisible]);

  useEffect(() => {
    if (!near) return;
    let task: RenderTask | null = null;
    let cancelled = false;
    (async () => {
      const page = await doc.getPage(pageNumber);
      if (cancelled || !canvasRef.current) return;
      const base = page.getViewport({ scale: 1 });
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const vp = page.getViewport({ scale: (width / base.width) * dpr });
      const canvas = canvasRef.current;
      canvas.width = Math.floor(vp.width);
      canvas.height = Math.floor(vp.height);
      setPageHeight(Math.round(vp.height / dpr));
      task = page.render({ canvasContext: canvas.getContext("2d")!, viewport: vp });
      await task.promise.catch(() => undefined);
    })();
    return () => {
      cancelled = true;
      task?.cancel();
    };
  }, [near, doc, pageNumber, width]);

  return (
    <div
      ref={boxRef}
      className="relative bg-paper shadow-card"
      style={{ width, height: near ? pageHeight : height }}
    >
      {near ? (
        <canvas ref={canvasRef} className="block h-full w-full" />
      ) : (
        <span className="absolute inset-0 grid place-items-center text-xs text-muted-foreground">{pageNumber}</span>
      )}
    </div>
  );
}
