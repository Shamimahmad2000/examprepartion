import { Link } from "@tanstack/react-router";
import { EXAMS } from "@/lib/exams";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-ink-gradient text-ink-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3">
        <div>
          <p className="font-display text-2xl font-semibold">Pariksha Path</p>
          <p className="mt-2 max-w-xs text-sm text-ink-muted">
            Free, organised notes for CTET, STET, BPSC and other competitive exams. Run by Shamim Ahmad.
          </p>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-accent">Exams</p>
          <ul className="mt-3 grid grid-cols-2 gap-2 text-sm">
            {EXAMS.map((e) => (
              <li key={e.slug}>
                <Link to="/exams/$examSlug" params={{ examSlug: e.slug }} className="text-ink-muted hover:text-ink-foreground">
                  {e.short}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-accent">Quick links</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/notes" className="text-ink-muted hover:text-ink-foreground">All notes</Link></li>
            <li><Link to="/about" className="text-ink-muted hover:text-ink-foreground">About Shamim Ahmad</Link></li>
            <li><Link to="/admin" className="text-ink-muted hover:text-ink-foreground">Admin — upload notes</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10 py-5 text-center text-xs text-ink-muted">
        © {new Date().getFullYear()} Pariksha Path · Run by Shamim Ahmad
      </div>
    </footer>
  );
}
