import { Link } from "@tanstack/react-router";
import { FileText, ArrowUpRight } from "lucide-react";
import type { Note } from "@/lib/notes.functions";
import { formatBytes, getExam, getSubject } from "@/lib/exams";

export function NoteCard({ note, showExam = true }: { note: Note; showExam?: boolean }) {
  const exam = getExam(note.exam_slug);
  const subject = getSubject(note.exam_slug, note.subject_slug);
  const meta = [note.pages ? `${note.pages} pages` : null, formatBytes(note.file_size), note.language].filter(Boolean);
  return (
    <Link
      to="/notes/$noteId"
      params={{ noteId: note.id }}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card p-5 shadow-card transition-all hover:-translate-y-0.5 hover:shadow-lift"
    >
      <span className="absolute inset-y-0 left-0 w-1 bg-marigold-gradient" />
      <div className="flex items-start gap-4">
        <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-secondary text-primary">
          <FileText className="size-5" />
        </span>
        <div className="min-w-0 flex-1">
          {showExam && (
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-marigold">
              {exam?.short ?? note.exam_slug} · {subject?.name ?? note.subject_slug}
            </p>
          )}
          <h3 className="mt-1 font-display text-lg font-semibold leading-snug text-card-foreground">{note.title}</h3>
          {note.description && (
            <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{note.description}</p>
          )}
          <p className="mt-3 text-xs text-muted-foreground">{meta.join(" · ")}</p>
        </div>
        <ArrowUpRight className="size-5 shrink-0 text-muted-foreground transition-colors group-hover:text-primary" />
      </div>
    </Link>
  );
}
