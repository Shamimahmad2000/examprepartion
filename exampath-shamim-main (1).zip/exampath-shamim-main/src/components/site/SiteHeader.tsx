import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, BookOpenText, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/exams", label: "Exams" },
  { to: "/notes", label: "All Notes" },
  { to: "/about", label: "About" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-lg bg-ink text-accent shadow-card">
            <BookOpenText className="size-5" />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-lg font-semibold text-foreground">Pariksha Path</span>
            <span className="block text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
              by Shamim Ahmad
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground data-[status=active]:text-primary"
            >
              {n.label}
            </Link>
          ))}
          <Button asChild variant="marigold" size="sm" className="ml-2">
            <Link to="/exams/$examSlug/$subjectSlug" params={{ examSlug: "ctet", subjectSlug: "sst" }}>
              CTET SST Notes
            </Link>
          </Button>
          <Button asChild variant="ink" size="sm" className="ml-2">
            <Link to="/admin"><ShieldCheck /> Admin Panel</Link>
          </Button>
        </nav>

        <button
          className="rounded-md p-2 text-foreground md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
      {open && (
        <nav className="border-t border-border bg-background px-4 pb-4 md:hidden">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              onClick={() => setOpen(false)}
              className="block border-b border-border/60 py-3 text-sm font-medium text-foreground"
            >
              {n.label}
            </Link>
          ))}
          <Link
            to="/admin"
            onClick={() => setOpen(false)}
            className="mt-3 flex items-center gap-2 rounded-md bg-ink px-3 py-3 text-sm font-semibold text-ink-foreground"
          >
            <ShieldCheck className="size-4" /> Super Admin Panel
          </Link>
        </nav>
      )}
    </header>
  );
}
