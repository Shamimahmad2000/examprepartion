import { describe, expect, it } from "vitest";
import { getSubject, validateNoteFile, EXAMS } from "@/lib/exams";

describe("exam sections", () => {
  it("has a CTET SST section", () => {
    expect(getSubject("ctet", "sst")?.name).toBe("Social Studies (SST)");
  });

  it("has a CTET Geography section", () => {
    expect(getSubject("ctet", "geography")?.name).toBe("Geography (SST)");
  });

  it("includes CTET, STET and BPSC", () => {
    const slugs = EXAMS.map((e) => e.slug);
    expect(slugs).toEqual(expect.arrayContaining(["ctet", "stet", "bpsc"]));
  });
});

describe("note upload rules", () => {
  it("accepts a PDF under 50 MB", () => {
    expect(validateNoteFile({ name: "a.pdf", type: "application/pdf", size: 20 * 1024 * 1024 })).toBeNull();
  });
  it("rejects a PDF over 50 MB", () => {
    expect(validateNoteFile({ name: "a.pdf", type: "application/pdf", size: 51 * 1024 * 1024 })).toMatch(/50 MB/);
  });
  it("rejects non-PDF files", () => {
    expect(validateNoteFile({ name: "a.docx", type: "application/msword", size: 1000 })).toMatch(/PDF/);
  });
});
