import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export type Note = Database["public"]["Tables"]["notes"]["Row"];

const COLUMNS =
  "id, title, description, exam_slug, subject_slug, language, file_url, file_path, file_size, pages, uploaded_by, created_at, is_published";

function publicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient<Database>(process.env["SUPABASE_URL"]!, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const listNotes = createServerFn({ method: "GET" })
  .validator((input: { exam?: string; subject?: string }) => ({
    exam: typeof input?.exam === "string" ? input.exam.slice(0, 60) : undefined,
    subject: typeof input?.subject === "string" ? input.subject.slice(0, 60) : undefined,
  }))
  .handler(async ({ data }): Promise<Note[]> => {
    let q = publicClient().from("notes").select(COLUMNS).order("created_at", { ascending: false }).limit(500);
    if (data.exam) q = q.eq("exam_slug", data.exam);
    if (data.subject) q = q.eq("subject_slug", data.subject);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return (rows ?? []) as Note[];
  });

export const getNote = createServerFn({ method: "GET" })
  .validator((input: { id: string }) => ({ id: String(input?.id ?? "").slice(0, 64) }))
  .handler(async ({ data }): Promise<Note | null> => {
    if (!/^[0-9a-f-]{36}$/i.test(data.id)) return null;
    const { data: row, error } = await publicClient().from("notes").select(COLUMNS).eq("id", data.id).maybeSingle();
    if (error) throw new Error(error.message);
    return (row as Note) ?? null;
  });

/**
 * Issues a short-lived download link for a published, storage-backed note.
 * Storage has no public read rule; the published check happens here, then a privileged client signs the link.
 */
export const getNoteFileUrl = createServerFn({ method: "GET" })
  .validator((input: { id: string }) => ({ id: String(input?.id ?? "").slice(0, 64) }))
  .handler(async ({ data }): Promise<string | null> => {
    if (!/^[0-9a-f-]{36}$/i.test(data.id)) return null;
    const { data: row, error } = await publicClient()
      .from("notes")
      .select("file_path, is_published")
      .eq("id", data.id)
      .eq("is_published", true)
      .maybeSingle();
    if (error || !row?.file_path) return null;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error: signErr } = await supabaseAdmin.storage
      .from("notes")
      .createSignedUrl(row.file_path, 60 * 60 * 6);
    if (signErr) {
      console.error("getNoteFileUrl sign failed", signErr);
      return null;
    }
    return signed?.signedUrl ?? null;
  });
