import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getNoteFileUrl, type Note } from "./notes.functions";

/**
 * Uploaded notes live in private storage and need a short-lived link; built-in notes have a direct URL.
 * Published notes get their link from the server; the admin falls back to signing directly (admin-only storage rule).
 */
export function useNoteFileUrl(note: Pick<Note, "id" | "file_url" | "file_path">) {
  const [url, setUrl] = useState<string | null>(note.file_path ? null : note.file_url);
  useEffect(() => {
    if (!note.file_path) {
      setUrl(note.file_url);
      return;
    }
    let cancelled = false;
    const path = note.file_path;
    (async () => {
      let signed = await getNoteFileUrl({ data: { id: note.id } }).catch(() => null);
      if (!signed) {
        const { data } = await supabase.storage.from("notes").createSignedUrl(path, 60 * 60 * 6);
        signed = data?.signedUrl ?? null;
      }
      if (!cancelled) setUrl(signed);
    })();
    return () => {
      cancelled = true;
    };
  }, [note.id, note.file_path, note.file_url]);
  return url;
}
