import { queryOptions } from "@tanstack/react-query";
import { getNote, listNotes } from "./notes.functions";

export const notesQuery = (filter: { exam?: string; subject?: string } = {}) =>
  queryOptions({
    queryKey: ["notes", filter.exam ?? "all", filter.subject ?? "all"],
    queryFn: () => listNotes({ data: filter }),
  });

export const noteQuery = (id: string) =>
  queryOptions({
    queryKey: ["notes", "one", id],
    queryFn: () => getNote({ data: { id } }),
  });
