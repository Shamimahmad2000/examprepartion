export type Subject = { slug: string; name: string; hindi: string };
export type Exam = {
  slug: string;
  short: string;
  name: string;
  hindi: string;
  blurb: string;
  subjects: Subject[];
};

const S = (slug: string, name: string, hindi: string): Subject => ({ slug, name, hindi });

export const EXAMS: Exam[] = [
  {
    slug: "ctet",
    short: "CTET",
    name: "Central Teacher Eligibility Test",
    hindi: "केंद्रीय शिक्षक पात्रता परीक्षा",
    blurb: "Paper 1 & Paper 2 notes, MCQs and pedagogy sets for every CTET subject.",
    subjects: [
      S("cdp", "Child Development & Pedagogy", "बाल विकास एवं शिक्षाशास्त्र"),
      S("sst", "Social Studies (SST)", "सामाजिक अध्ययन"),
      S("geography", "Geography (SST)", "भूगोल"),
      S("maths", "Mathematics", "गणित"),
      S("science", "Science", "विज्ञान"),
      S("evs", "Environmental Studies (EVS)", "पर्यावरण अध्ययन"),
      S("hindi", "Hindi Language", "हिंदी भाषा"),
      S("english", "English Language", "अंग्रेज़ी भाषा"),
      S("urdu", "Urdu Language", "उर्दू भाषा"),
      S("sanskrit", "Sanskrit Language", "संस्कृत भाषा"),
    ],
  },
  {
    slug: "stet",
    short: "STET",
    name: "State Teacher Eligibility Test",
    hindi: "राज्य शिक्षक पात्रता परीक्षा",
    blurb: "Bihar STET and other state TET subject notes for secondary & senior secondary.",
    subjects: [
      S("sst", "Social Science", "सामाजिक विज्ञान"),
      S("maths", "Mathematics", "गणित"),
      S("science", "Science", "विज्ञान"),
      S("hindi", "Hindi", "हिंदी"),
      S("english", "English", "अंग्रेज़ी"),
      S("urdu", "Urdu", "उर्दू"),
      S("sanskrit", "Sanskrit", "संस्कृत"),
      S("computer", "Computer Science", "कंप्यूटर विज्ञान"),
    ],
  },
  {
    slug: "bpsc-tre",
    short: "BPSC TRE",
    name: "BPSC Teacher Recruitment Exam",
    hindi: "बीपीएससी शिक्षक भर्ती परीक्षा",
    blurb: "Notes for BPSC TRE classes 1–5, 6–8, 9–10 and 11–12 including GS and language.",
    subjects: [
      S("general-studies", "General Studies", "सामान्य अध्ययन"),
      S("language", "Language (Hindi / English)", "भाषा"),
      S("cdp", "Child Development & Pedagogy", "बाल विकास एवं शिक्षाशास्त्र"),
      S("sst", "Social Science", "सामाजिक विज्ञान"),
      S("maths", "Mathematics", "गणित"),
      S("science", "Science", "विज्ञान"),
    ],
  },
  {
    slug: "bpsc",
    short: "BPSC",
    name: "Bihar Public Service Commission (CCE)",
    hindi: "बिहार लोक सेवा आयोग",
    blurb: "Prelims & Mains notes — History, Polity, Geography, Economy and Bihar special.",
    subjects: [
      S("history", "History", "इतिहास"),
      S("polity", "Indian Polity", "भारतीय राजव्यवस्था"),
      S("geography", "Geography", "भूगोल"),
      S("economy", "Economy", "अर्थव्यवस्था"),
      S("bihar-gk", "Bihar Special GK", "बिहार विशेष"),
      S("current-affairs", "Current Affairs", "समसामयिकी"),
      S("science", "General Science", "सामान्य विज्ञान"),
    ],
  },
  {
    slug: "ssc",
    short: "SSC",
    name: "Staff Selection Commission",
    hindi: "कर्मचारी चयन आयोग",
    blurb: "CGL, CHSL, MTS and GD notes for maths, reasoning, English and GK.",
    subjects: [
      S("maths", "Quantitative Aptitude", "गणित"),
      S("reasoning", "Reasoning", "तर्कशक्ति"),
      S("english", "English", "अंग्रेज़ी"),
      S("gk", "General Awareness", "सामान्य ज्ञान"),
    ],
  },
  {
    slug: "railway",
    short: "Railway",
    name: "Railway Exams (NTPC / Group D)",
    hindi: "रेलवे परीक्षा",
    blurb: "RRB NTPC, Group D and ALP notes with previous year questions.",
    subjects: [
      S("maths", "Mathematics", "गणित"),
      S("reasoning", "Reasoning", "तर्कशक्ति"),
      S("gk", "General Awareness", "सामान्य ज्ञान"),
      S("science", "General Science", "सामान्य विज्ञान"),
    ],
  },
];

export function getExam(slug: string): Exam | undefined {
  return EXAMS.find((e) => e.slug === slug);
}

export function getSubject(examSlug: string, subjectSlug: string): Subject | undefined {
  return getExam(examSlug)?.subjects.find((s) => s.slug === subjectSlug);
}

/** Largest note file the admin can upload (matches the storage limit). */
export const MAX_NOTE_FILE_BYTES = 50 * 1024 * 1024;
export const ALLOWED_NOTE_TYPES = ["application/pdf"];

export function validateNoteFile(file: { type: string; size: number; name: string }): string | null {
  const isPdf = ALLOWED_NOTE_TYPES.includes(file.type) || file.name.toLowerCase().endsWith(".pdf");
  if (!isPdf) return "Only PDF files can be uploaded.";
  if (file.size > MAX_NOTE_FILE_BYTES) return "File is larger than 50 MB.";
  if (file.size === 0) return "This file is empty.";
  return null;
}

export function formatBytes(bytes: number | null | undefined): string {
  if (!bytes) return "";
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
