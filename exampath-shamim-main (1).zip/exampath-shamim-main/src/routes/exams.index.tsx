import { createFileRoute, Link } from "@tanstack/react-router";
import { EXAMS } from "@/lib/exams";

export const Route = createFileRoute("/exams/")({
  head: () => ({
    meta: [
      { title: "All Exams — CTET, STET, BPSC, SSC, Railway | Pariksha Path" },
      { name: "description", content: "Pick your competitive exam to find subject-wise notes and MCQs." },
      { property: "og:title", content: "All Exams | Pariksha Path" },
      { property: "og:description", content: "CTET, STET, BPSC TRE, BPSC, SSC and Railway notes in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ExamsPage,
});

function ExamsPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-marigold">परीक्षाएँ</p>
      <h1 className="mt-2 text-4xl font-semibold sm:text-5xl">All exams</h1>
      <p className="mt-3 max-w-2xl text-muted-foreground">Choose an exam, then a subject, to open its notes.</p>
      <div className="mt-10 space-y-6">
        {EXAMS.map((e) => (
          <section key={e.slug} className="rounded-2xl border border-border bg-card p-6 shadow-card sm:p-8">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <div>
                <Link to="/exams/$examSlug" params={{ examSlug: e.slug }} className="font-display text-3xl font-semibold text-primary hover:underline">
                  {e.short}
                </Link>
                <p className="text-sm text-muted-foreground">{e.name} · {e.hindi}</p>
              </div>
              <Link to="/exams/$examSlug" params={{ examSlug: e.slug }} className="text-sm font-medium text-primary hover:underline">
                Open section →
              </Link>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {e.subjects.map((s) => (
                <Link
                  key={s.slug}
                  to="/exams/$examSlug/$subjectSlug"
                  params={{ examSlug: e.slug, subjectSlug: s.slug }}
                  className="rounded-full border border-border bg-background px-3.5 py-1.5 text-sm text-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  {s.name}
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
