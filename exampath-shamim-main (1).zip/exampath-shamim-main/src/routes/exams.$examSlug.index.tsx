import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { getExam } from "@/lib/exams";
import { notesQuery } from "@/lib/notes.queries";

export const Route = createFileRoute("/exams/$examSlug/")({
  loader: async ({ params, context }) => {
    const exam = getExam(params.examSlug);
    if (!exam) throw notFound();
    await context.queryClient.ensureQueryData(notesQuery({ exam: exam.slug }));
    return { short: exam.short, name: exam.name };
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `${loaderData.short} Notes — ${loaderData.name} | Pariksha Path` : "Exam not found | Pariksha Path";
    const desc = loaderData
      ? `Subject-wise ${loaderData.short} notes and MCQs. Free to read and download.`
      : "This exam section does not exist.";
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
        ...(loaderData ? [] : [{ name: "robots", content: "noindex" }]),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-3xl font-semibold">Exam not found</h1>
      <Link to="/exams" className="mt-4 inline-block text-primary hover:underline">See all exams</Link>
    </div>
  ),
  component: ExamPage,
});

function ExamPage() {
  const { examSlug } = Route.useParams();
  const exam = getExam(examSlug)!;
  const { data: notes } = useSuspenseQuery(notesQuery({ exam: exam.slug }));
  const count = (s: string) => notes.filter((n) => n.subject_slug === s).length;

  return (
    <>
      <section className="bg-ink-gradient text-ink-foreground">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
          <Link to="/exams" className="text-sm text-ink-muted hover:text-ink-foreground">← All exams</Link>
          <h1 className="mt-4 text-5xl font-semibold">{exam.short}</h1>
          <p className="mt-2 text-lg text-ink-foreground">{exam.name}</p>
          <p className="text-ink-muted">{exam.hindi}</p>
          <p className="mt-4 max-w-2xl text-ink-muted">{exam.blurb}</p>
        </div>
      </section>
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <h2 className="text-2xl font-semibold">Subjects</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {exam.subjects.map((s) => {
            const c = count(s.slug);
            return (
              <Link
                key={s.slug}
                to="/exams/$examSlug/$subjectSlug"
                params={{ examSlug: exam.slug, subjectSlug: s.slug }}
                className="group flex items-center justify-between rounded-xl border border-border bg-card p-5 shadow-card transition-all hover:-translate-y-0.5 hover:shadow-lift"
              >
                <div>
                  <p className="font-display text-lg font-semibold text-foreground group-hover:text-primary">{s.name}</p>
                  <p className="text-sm text-muted-foreground">{s.hindi}</p>
                </div>
                <span
                  className={
                    c > 0
                      ? "rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold text-accent-foreground"
                      : "rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground"
                  }
                >
                  {c} {c === 1 ? "note" : "notes"}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </>
  );
}
