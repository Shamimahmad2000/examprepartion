import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { FileQuestion } from "lucide-react";
import { NoteCard } from "@/components/site/NoteCard";
import { getExam, getSubject } from "@/lib/exams";
import { notesQuery } from "@/lib/notes.queries";

export const Route = createFileRoute("/exams/$examSlug/$subjectSlug")({
  loader: async ({ params, context }) => {
    const exam = getExam(params.examSlug);
    const subject = getSubject(params.examSlug, params.subjectSlug);
    if (!exam || !subject) throw notFound();
    await context.queryClient.ensureQueryData(notesQuery({ exam: exam.slug, subject: subject.slug }));
    return { exam: exam.short, subject: subject.name };
  },
  head: ({ loaderData }) => {
    const title = loaderData
      ? `${loaderData.exam} ${loaderData.subject} Notes & MCQs | Pariksha Path`
      : "Subject not found | Pariksha Path";
    const desc = loaderData
      ? `Download free ${loaderData.exam} ${loaderData.subject} notes and practice MCQs.`
      : "This subject section does not exist.";
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
        ...(loaderData ? [] : [{ name: "robots", content: "noindex" }]),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-3xl font-semibold">Subject not found</h1>
      <Link to="/exams" className="mt-4 inline-block text-primary hover:underline">See all exams</Link>
    </div>
  ),
  component: SubjectPage,
});

function SubjectPage() {
  const { examSlug, subjectSlug } = Route.useParams();
  const exam = getExam(examSlug)!;
  const subject = getSubject(examSlug, subjectSlug)!;
  const { data: notes } = useSuspenseQuery(notesQuery({ exam: exam.slug, subject: subject.slug }));

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <nav className="text-sm text-muted-foreground">
        <Link to="/exams" className="hover:text-foreground">Exams</Link>
        <span className="mx-2">/</span>
        <Link to="/exams/$examSlug" params={{ examSlug: exam.slug }} className="hover:text-foreground">{exam.short}</Link>
        <span className="mx-2">/</span>
        <span className="text-foreground">{subject.name}</span>
      </nav>
      <h1 className="mt-4 text-4xl font-semibold sm:text-5xl">
        {exam.short} · {subject.name}
      </h1>
      <p className="mt-2 text-lg text-muted-foreground">{subject.hindi}</p>

      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {notes.map((n) => (
          <NoteCard key={n.id} note={n} showExam={false} />
        ))}
      </div>

      {notes.length === 0 && (
        <div className="mt-6 rounded-2xl border border-dashed border-border bg-paper p-12 text-center">
          <FileQuestion className="mx-auto size-10 text-muted-foreground" />
          <p className="mt-3 font-display text-xl font-semibold">Notes coming soon</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Notes for {exam.short} {subject.name} will be uploaded here shortly.
          </p>
        </div>
      )}

      <div className="mt-12">
        <p className="text-sm font-semibold text-foreground">Other {exam.short} subjects</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {exam.subjects
            .filter((s) => s.slug !== subject.slug)
            .map((s) => (
              <Link
                key={s.slug}
                to="/exams/$examSlug/$subjectSlug"
                params={{ examSlug: exam.slug, subjectSlug: s.slug }}
                className="rounded-full border border-border bg-card px-3.5 py-1.5 text-sm hover:border-primary hover:text-primary"
              >
                {s.name}
              </Link>
            ))}
        </div>
      </div>
    </div>
  );
}
