import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Download, ExternalLink, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatBytes, getExam, getSubject } from "@/lib/exams";
import { noteQuery } from "@/lib/notes.queries";
import { useNoteFileUrl } from "@/lib/note-file";
import type { Note } from "@/lib/notes.functions";
import { PdfViewer } from "@/components/site/PdfViewer";

export const Route = createFileRoute("/notes/$noteId")({
  loader: async ({ params, context }) => {
    const note = await context.queryClient.ensureQueryData(noteQuery(params.noteId));
    if (!note) throw notFound();
    return { title: note.title, description: note.description };
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `${loaderData.title} | Pariksha Path` : "Note unavailable | Pariksha Path";
    const desc = loaderData?.description?.slice(0, 155) ?? "Free exam notes on Pariksha Path.";
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
        ...(loaderData ? [] : [{ name: "robots", content: "noindex" }]),
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-3xl font-semibold">Note not found</h1>
      <Link to="/notes" className="mt-4 inline-block text-primary hover:underline">Browse all notes</Link>
    </div>
  ),
  component: NotePage,
});

function NotePage() {
  const { noteId } = Route.useParams();
  const { data: note } = useSuspenseQuery(noteQuery(noteId));
  if (!note) return null;
  return <NoteView note={note} />;
}

function NoteView({ note }: { note: Note }) {
  const exam = getExam(note.exam_slug);
  const subject = getSubject(note.exam_slug, note.subject_slug);
  const url = useNoteFileUrl(note);
  const meta = [note.pages ? `${note.pages} pages` : null, formatBytes(note.file_size), note.language].filter(Boolean);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <nav className="text-sm text-muted-foreground">
        <Link to="/exams/$examSlug" params={{ examSlug: note.exam_slug }} className="hover:text-foreground">
          {exam?.short ?? note.exam_slug}
        </Link>
        <span className="mx-2">/</span>
        <Link
          to="/exams/$examSlug/$subjectSlug"
          params={{ examSlug: note.exam_slug, subjectSlug: note.subject_slug }}
          className="hover:text-foreground"
        >
          {subject?.name ?? note.subject_slug}
        </Link>
      </nav>

      <div className="mt-4 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div className="max-w-3xl">
          <h1 className="text-3xl font-semibold leading-tight sm:text-4xl">{note.title}</h1>
          {note.description && <p className="mt-3 text-muted-foreground">{note.description}</p>}
          <p className="mt-3 text-sm text-muted-foreground">{meta.join(" · ")}</p>
        </div>
        <div className="flex shrink-0 gap-2">
          {url ? (
            <>
              <Button asChild variant="outline" size="lg">
                <a href={url} target="_blank" rel="noreferrer">
                  <ExternalLink /> Open
                </a>
              </Button>
              <Button asChild variant="marigold" size="lg">
                <a href={url} download>
                  <Download /> Download PDF
                </a>
              </Button>
            </>
          ) : (
            <Button disabled size="lg" variant="outline">
              <Loader2 className="animate-spin" /> Preparing…
            </Button>
          )}
        </div>
      </div>

      <div className="mt-8">
        {url ? (
          <PdfViewer url={url} />
        ) : (
          <div className="grid h-[60vh] place-items-center rounded-2xl border border-border bg-card text-muted-foreground">
            Loading preview…
          </div>
        )}
      </div>
    </div>
  );
}
