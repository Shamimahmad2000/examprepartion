import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowRight, BookMarked, Languages, Download } from "lucide-react";
import heroImg from "@/assets/hero-study-desk.jpg";
import { Button } from "@/components/ui/button";
import { NoteCard } from "@/components/site/NoteCard";
import { EXAMS } from "@/lib/exams";
import { notesQuery } from "@/lib/notes.queries";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pariksha Path — CTET, STET & BPSC Notes by Shamim Ahmad" },
      {
        name: "description",
        content:
          "Free bilingual notes and MCQs for CTET, STET, BPSC TRE, BPSC, SSC and Railway exams, organised subject-wise. Run by Shamim Ahmad.",
      },
      { property: "og:title", content: "Pariksha Path — Competitive Exam Notes" },
      { property: "og:description", content: "Subject-wise notes for CTET, STET, BPSC and more. Run by Shamim Ahmad." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(notesQuery()),
  component: Home,
});

function Home() {
  const { data: notes } = useSuspenseQuery(notesQuery());
  const countByExam = notes.reduce<Record<string, number>>((acc, n) => {
    acc[n.exam_slug] = (acc[n.exam_slug] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-ink-gradient text-ink-foreground">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 md:grid-cols-[1.05fr_1fr] md:py-24">
          <div className="animate-rise">
            <p className="inline-flex items-center gap-2 rounded-full border border-ink-foreground/20 px-3 py-1 text-xs font-medium tracking-wide text-accent">
              पढ़ाई आसान · तैयारी पक्की
            </p>
            <h1 className="mt-5 text-4xl font-semibold leading-[1.05] sm:text-5xl lg:text-6xl">
              Notes that get you <span className="text-accent">selected.</span>
            </h1>
            <p className="mt-5 max-w-lg text-base text-ink-muted sm:text-lg">
              Subject-wise notes and MCQ sets for CTET, STET, BPSC and other competitive exams — free to read
              and download.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="marigold" size="xl">
                <Link to="/exams">
                  Browse exams <ArrowRight />
                </Link>
              </Button>
              <Button asChild variant="ink-outline" size="xl">
                <Link to="/exams/$examSlug/$subjectSlug" params={{ examSlug: "ctet", subjectSlug: "sst" }}>
                  CTET SST notes
                </Link>
              </Button>
            </div>
            <p className="mt-8 text-sm text-ink-muted">
              Run by <span className="font-semibold text-ink-foreground">Shamim Ahmad</span>
            </p>
          </div>
          <div className="animate-rise [animation-delay:150ms]">
            <img
              src={heroImg}
              alt="A study desk with exam books, notebook, lamp and chai"
              width={1536}
              height={1152}
              className="aspect-[4/3] w-full rounded-2xl object-cover shadow-lift ring-1 ring-ink-foreground/10"
            />
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-b border-border bg-paper">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:grid-cols-3 sm:px-6">
          {[
            { icon: BookMarked, t: "Subject-wise", d: "Every exam split into its own subjects." },
            { icon: Languages, t: "Hindi + English", d: "Bilingual notes wherever possible." },
            { icon: Download, t: "Free PDFs", d: "Read online or download for offline study." },
          ].map((f) => (
            <div key={f.t} className="flex items-start gap-3">
              <f.icon className="mt-0.5 size-5 text-marigold" />
              <div>
                <p className="font-semibold text-foreground">{f.t}</p>
                <p className="text-sm text-muted-foreground">{f.d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Exams */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-marigold">Choose your exam</p>
            <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">Exam sections</h2>
          </div>
          <Link to="/exams" className="hidden text-sm font-medium text-primary hover:underline sm:block">
            View all →
          </Link>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {EXAMS.map((e) => (
            <Link
              key={e.slug}
              to="/exams/$examSlug"
              params={{ examSlug: e.slug }}
              className="group rounded-xl border border-border bg-card p-6 shadow-card transition-all hover:-translate-y-0.5 hover:shadow-lift"
            >
              <div className="flex items-center justify-between">
                <span className="font-display text-2xl font-semibold text-primary">{e.short}</span>
                <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground">
                  {countByExam[e.slug] ?? 0} {(countByExam[e.slug] ?? 0) === 1 ? "note" : "notes"}
                </span>
              </div>
              <p className="mt-1 text-sm font-medium text-foreground">{e.name}</p>
              <p className="text-sm text-muted-foreground">{e.hindi}</p>
              <p className="mt-3 text-sm text-muted-foreground">{e.blurb}</p>
              <p className="mt-4 text-sm font-medium text-primary group-hover:underline">
                {e.subjects.length} subjects →
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* Latest notes */}
      <section className="bg-ruled">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-marigold">Fresh uploads</p>
          <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">Latest notes</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            {notes.slice(0, 6).map((n) => (
              <NoteCard key={n.id} note={n} />
            ))}
            {notes.length === 0 && <p className="text-muted-foreground">No notes yet.</p>}
          </div>
        </div>
      </section>
    </>
  );
}
