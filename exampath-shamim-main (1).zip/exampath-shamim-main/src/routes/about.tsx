import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Shamim Ahmad | Pariksha Path" },
      { name: "description", content: "Pariksha Path is run by Shamim Ahmad to share free notes for CTET, STET, BPSC and more." },
      { property: "og:title", content: "About Shamim Ahmad | Pariksha Path" },
      { property: "og:description", content: "Why Pariksha Path exists and who runs it." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-marigold">About</p>
      <h1 className="mt-2 text-4xl font-semibold sm:text-5xl">Run by Shamim Ahmad</h1>
      <div className="mt-8 space-y-5 text-lg leading-relaxed text-foreground/90">
        <p>
          Pariksha Path is a simple place to find well-organised study material for teaching and government
          job exams — CTET, STET, BPSC TRE, BPSC, SSC, Railway and more.
        </p>
        <p>
          Every exam is split into its subjects, so you can go straight to what you need — for example CTET
          → Social Studies — and read or download the notes for free.
        </p>
        <p>New notes are added regularly. Keep practising, and all the best for your exam!</p>
      </div>
      <Button asChild variant="marigold" size="xl" className="mt-10">
        <Link to="/exams">Start studying</Link>
      </Button>
    </div>
  );
}
