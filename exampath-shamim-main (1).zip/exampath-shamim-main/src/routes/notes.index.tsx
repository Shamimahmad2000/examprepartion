import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { NoteCard } from "@/components/site/NoteCard";
import { EXAMS } from "@/lib/exams";
import { notesQuery } from "@/lib/notes.queries";

export const Route = createFileRoute("/notes/")({
  head: () => ({
    meta: [
      { title: "All Notes — Search CTET, STET, BPSC PDFs | Pariksha Path" },
      { name: "description", content: "Search every uploaded note and MCQ PDF across all competitive exams." },
      { property: "og:title", content: "All Notes | Pariksha Path" },
      { property: "og:description", content: "Search notes for CTET, STET, BPSC, SSC and Railway." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(notesQuery()),
  component: AllNotes,
});

function AllNotes() {
  const { data: notes } = useSuspenseQuery(notesQuery());
  const [q, setQ] = useState("");
  const [exam, setExam] = useState("all");

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return notes.filter(
      (n) =>
        (exam === "all" || n.exam_slug === exam) &&
        (!term || n.title.toLowerCase().includes(term) || (n.description ?? "").toLowerCase().includes(term)),
    );
  }, [notes, q, exam]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <h1 className="text-4xl font-semibold sm:text-5xl">All notes</h1>
      <p className="mt-2 text-muted-foreground">{notes.length} notes across all exams.</p>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search notes…" className="h-11 bg-card pl-9" />
        </div>
        <div className="flex flex-wrap gap-2">
          {[{ slug: "all", short: "All" }, ...EXAMS].map((e) => (
            <button
              key={e.slug}
              onClick={() => setExam(e.slug)}
              className={
                exam === e.slug
                  ? "h-11 rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
                  : "h-11 rounded-lg border border-border bg-card px-4 text-sm text-foreground hover:border-primary"
              }
            >
              {e.short}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        {filtered.map((n) => (
          <NoteCard key={n.id} note={n} />
        ))}
      </div>
      {filtered.length === 0 && <p className="mt-10 text-center text-muted-foreground">No notes match your search.</p>}
    </div>
  );
}
