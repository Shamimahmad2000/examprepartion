import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRef, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Trash2, Upload, LogOut, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { EXAMS, formatBytes, getExam, getSubject, validateNoteFile } from "@/lib/exams";
import { notesQuery } from "@/lib/notes.queries";
import type { Note } from "@/lib/notes.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Upload Notes — Admin | Pariksha Path" },
      { name: "description", content: "Admin panel to upload and manage notes." },
      { property: "og:title", content: "Admin | Pariksha Path" },
      { property: "og:description", content: "Upload and manage notes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const selectCls =
  "flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring";

function AdminPage() {
  const { user, isAdmin, loading } = useAuth();
  const navigate = useNavigate();

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  if (loading) return <div className="mx-auto max-w-5xl px-4 py-16 text-muted-foreground">Loading…</div>;

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <ShieldAlert className="mx-auto size-10 text-marigold" />
        <h1 className="mt-4 text-3xl font-semibold">Admin only</h1>
        <p className="mt-2 text-muted-foreground">
          You are signed in as {user?.email}, but this account is not the site admin.
        </p>
        <Button variant="outline" className="mt-6" onClick={signOut}>
          <LogOut /> Sign out
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-marigold">Admin</p>
          <h1 className="mt-1 text-4xl font-semibold">Upload notes</h1>
          <p className="text-sm text-muted-foreground">Signed in as {user?.email}</p>
        </div>
        <Button variant="outline" onClick={signOut}>
          <LogOut /> Sign out
        </Button>
      </div>
      <UploadForm userId={user!.id} />
      <ManageNotes />
      <ChangePassword />
    </div>
  );
}

function UploadForm({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [examSlug, setExamSlug] = useState("ctet");
  const [subjectSlug, setSubjectSlug] = useState("sst");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [language, setLanguage] = useState("Hindi + English");
  const [pages, setPages] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  const exam = getExam(examSlug)!;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!file) {
      toast.error("Choose a PDF file first.");
      return;
    }
    const problem = validateNoteFile(file);
    if (problem) {
      toast.error(problem);
      return;
    }
    setBusy(true);
    try {
      const safeName = file.name.replace(/[^a-zA-Z0-9.\-_]+/g, "-").toLowerCase();
      const path = `${examSlug}/${subjectSlug}/${crypto.randomUUID()}-${safeName}`;
      const { error: upErr } = await supabase.storage
        .from("notes")
        .upload(path, file, { contentType: "application/pdf", upsert: false });
      if (upErr) throw upErr;
      const { error: insErr } = await supabase.from("notes").insert({
        title: title.trim() || file.name.replace(/\.pdf$/i, ""),
        description: description.trim() || null,
        exam_slug: examSlug,
        subject_slug: subjectSlug,
        language,
        file_url: "",
        file_path: path,
        file_size: file.size,
        pages: pages ? Number(pages) : null,
        uploaded_by: userId,
      });
      if (insErr) {
        await supabase.storage.from("notes").remove([path]);
        throw insErr;
      }
      toast.success("Note uploaded!");
      setTitle("");
      setDescription("");
      setPages("");
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
      await qc.invalidateQueries({ queryKey: ["notes"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-8 grid gap-5 rounded-2xl border border-border bg-card p-6 shadow-card sm:grid-cols-2 sm:p-8">
      <div className="space-y-1.5">
        <Label htmlFor="exam">Exam</Label>
        <select
          id="exam"
          className={selectCls}
          value={examSlug}
          onChange={(e) => {
            setExamSlug(e.target.value);
            setSubjectSlug(getExam(e.target.value)?.subjects[0]?.slug ?? "");
          }}
        >
          {EXAMS.map((x) => (
            <option key={x.slug} value={x.slug}>{x.short} — {x.name}</option>
          ))}
        </select>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="subject">Subject / section</Label>
        <select id="subject" className={selectCls} value={subjectSlug} onChange={(e) => setSubjectSlug(e.target.value)}>
          {exam.subjects.map((s) => (
            <option key={s.slug} value={s.slug}>{s.name}</option>
          ))}
        </select>
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="title">Title</Label>
        <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. CTET SST — Chapter-wise Notes" />
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="desc">Description (optional)</Label>
        <Textarea id="desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="lang">Language</Label>
        <select id="lang" className={selectCls} value={language} onChange={(e) => setLanguage(e.target.value)}>
          <option>Hindi + English</option>
          <option>Hindi</option>
          <option>English</option>
          <option>Urdu</option>
        </select>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="pages">Pages (optional)</Label>
        <Input id="pages" type="number" min={1} value={pages} onChange={(e) => setPages(e.target.value)} />
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="file">PDF file (max 50 MB)</Label>
        <Input
          id="file"
          ref={fileRef}
          type="file"
          accept="application/pdf,.pdf"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="h-auto py-2"
        />
        {file && <p className="text-xs text-muted-foreground">{file.name} · {formatBytes(file.size)}</p>}
      </div>
      <div className="sm:col-span-2">
        <Button type="submit" variant="marigold" size="xl" disabled={busy}>
          <Upload /> {busy ? "Uploading…" : "Upload note"}
        </Button>
      </div>
    </form>
  );
}

function ManageNotes() {
  const qc = useQueryClient();
  const { data: notes = [] } = useQuery(notesQuery());

  async function remove(n: Note) {
    if (!confirm(`Delete “${n.title}”?`)) return;
    const { error } = await supabase.from("notes").delete().eq("id", n.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (n.file_path) await supabase.storage.from("notes").remove([n.file_path]);
    toast.success("Note deleted");
    qc.invalidateQueries({ queryKey: ["notes"] });
  }

  return (
    <section className="mt-12">
      <h2 className="text-2xl font-semibold">All uploaded notes ({notes.length})</h2>
      <div className="mt-4 divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
        {notes.map((n) => (
          <div key={n.id} className="flex items-center justify-between gap-4 p-4">
            <div className="min-w-0">
              <Link to="/notes/$noteId" params={{ noteId: n.id }} className="font-medium text-foreground hover:text-primary">
                {n.title}
              </Link>
              <p className="text-xs text-muted-foreground">
                {getExam(n.exam_slug)?.short} · {getSubject(n.exam_slug, n.subject_slug)?.name} · {formatBytes(n.file_size)}
              </p>
            </div>
            <Button variant="ghost" size="icon" aria-label={`Delete ${n.title}`} onClick={() => remove(n)}>
              <Trash2 className="text-destructive" />
            </Button>
          </div>
        ))}
      </div>
    </section>
  );
}

function ChangePassword() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (next.length < 8) {
      toast.error("New password must be at least 8 characters.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: next, current_password: current });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setCurrent("");
    setNext("");
    toast.success("Password changed");
  }

  return (
    <section className="mt-12">
      <h2 className="text-2xl font-semibold">Change password</h2>
      <form onSubmit={onSubmit} className="mt-4 grid max-w-xl gap-4 rounded-xl border border-border bg-card p-6 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="cur-pass">Current password</Label>
          <Input id="cur-pass" type="password" required autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="new-pass">New password</Label>
          <Input id="new-pass" type="password" required minLength={8} autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <Button type="submit" variant="ink" disabled={busy}>{busy ? "Saving…" : "Change password"}</Button>
        </div>
      </form>
    </section>
  );
}
