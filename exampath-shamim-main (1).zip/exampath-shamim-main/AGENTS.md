<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Exam and subject sections are defined in `src/lib/exams.ts`, not the database; notes reference them by slug. Why: sections change rarely and stay type-safe.
- Public note reads go through `src/lib/notes.functions.ts` server functions with the publishable client. Why: SSR-safe public data.
- Uploaded note PDFs live in the private `notes` storage bucket (public buckets are blocked) and are opened via short-lived signed links (`useNoteFileUrl`); built-in notes use a CDN asset URL in `file_url`. Why: workspace policy blocks public buckets.
- Only users with the `admin` role (in `user_roles`) can add or delete notes; only the owner email becomes admin via a signup trigger, and public sign-ups are disabled in auth settings (sign-in only UI). Why: the site owner is the only uploader.
- Note PDFs are shown with pdf.js (`PdfViewer`), never an iframe/embed. Why: the asset CDN sends `object-src 'none'`, so Chrome blocks its built-in PDF viewer.
