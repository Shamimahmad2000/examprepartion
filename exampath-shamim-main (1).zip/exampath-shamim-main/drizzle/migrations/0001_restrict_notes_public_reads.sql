ALTER TABLE public.notes ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT true;

DROP POLICY IF EXISTS "Anyone can view notes" ON public.notes;

CREATE POLICY "Anyone can view published notes"
ON public.notes FOR SELECT
TO anon, authenticated
USING (is_published = true);

CREATE POLICY "Admins can view all notes"
ON public.notes FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Public can read notes files" ON storage.objects;

CREATE POLICY "Anyone can read files of published notes"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (
  bucket_id = 'notes'
  AND EXISTS (
    SELECT 1 FROM public.notes n
    WHERE n.file_path = storage.objects.name
      AND n.is_published = true
  )
);

CREATE POLICY "Admins can read all notes files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'notes' AND public.has_role(auth.uid(), 'admin'::public.app_role));