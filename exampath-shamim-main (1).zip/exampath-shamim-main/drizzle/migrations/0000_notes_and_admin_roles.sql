create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create policy "Users can read own roles" on public.user_roles
  for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- First account ever created becomes the admin
create or replace function public.assign_first_admin()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'user') on conflict do nothing;
  end if;
  return new;
end;
$$;

create trigger on_auth_user_created_assign_role
  after insert on auth.users
  for each row execute function public.assign_first_admin();

create table public.notes (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  exam_slug text not null,
  subject_slug text not null,
  language text not null default 'Hindi + English',
  file_url text not null,
  file_path text,
  file_size bigint,
  pages integer,
  uploaded_by uuid,
  created_at timestamptz not null default now()
);
grant select on public.notes to anon;
grant select, insert, update, delete on public.notes to authenticated;
grant all on public.notes to service_role;
alter table public.notes enable row level security;

create policy "Anyone can view notes" on public.notes
  for select to anon, authenticated using (true);
create policy "Admins can add notes" on public.notes
  for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins can update notes" on public.notes
  for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins can delete notes" on public.notes
  for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

create index notes_exam_subject_idx on public.notes (exam_slug, subject_slug, created_at desc);

insert into public.notes (title, description, exam_slug, subject_slug, language, file_url, file_size, pages)
values (
  'CTET Feb 2026 — 1111 MCQs SST Pedagogy',
  'Bilingual (Hindi + English) practice set of 1111 MCQs covering Social Studies content and pedagogy: History, Geography, Political Science and SST teaching methods. Ideal for CTET Paper 2 (SST) preparation.',
  'ctet',
  'sst',
  'Hindi + English',
  '/__l5e/assets-v1/6e05e4a8-b517-4fad-b22c-f5472776d1a3/ctet-feb-2026-sst-pedagogy-1111-mcqs.pdf',
  20660963,
  244
);

-- Storage policies for the notes bucket
create policy "Public can read notes files" on storage.objects
  for select to anon, authenticated using (bucket_id = 'notes');
create policy "Admins can upload notes files" on storage.objects
  for insert to authenticated with check (bucket_id = 'notes' and public.has_role(auth.uid(), 'admin'));
create policy "Admins can delete notes files" on storage.objects
  for delete to authenticated using (bucket_id = 'notes' and public.has_role(auth.uid(), 'admin'));