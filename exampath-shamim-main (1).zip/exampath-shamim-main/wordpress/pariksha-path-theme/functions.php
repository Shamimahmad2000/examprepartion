<?php
/**
 * Pariksha Path theme setup.
 *
 * @package Pariksha_Path
 */

defined( 'ABSPATH' ) || exit;

define( 'PP_THEME_VERSION', '1.0.0' );

require_once get_template_directory() . '/inc/icons.php';
require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/seo.php';
require_once get_template_directory() . '/inc/setup-content.php';

/**
 * Theme features.
 */
function pp_theme_setup() {
	load_theme_textdomain( 'pariksha-path', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 72,
			'width'       => 72,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
	register_nav_menus(
		array(
			'primary' => __( 'Top menu', 'pariksha-path' ),
			'footer'  => __( 'Footer quick links', 'pariksha-path' ),
		)
	);
}
add_action( 'after_setup_theme', 'pp_theme_setup' );

/**
 * Styles and scripts.
 */
function pp_theme_assets() {
	$uri = get_template_directory_uri();
	wp_enqueue_style( 'pp-fonts', 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Hind:wght@400;500;600&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
	wp_enqueue_style( 'pp-theme', $uri . '/assets/css/theme.css', array(), PP_THEME_VERSION );
	wp_enqueue_script( 'pp-theme', $uri . '/assets/js/theme.js', array(), PP_THEME_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );

	if ( is_singular( 'pp_note' ) ) {
		wp_enqueue_script( 'pp-pdf-viewer', $uri . '/assets/js/pdf-viewer.js', array(), PP_THEME_VERSION, true );
	}
	if ( is_singular( 'post' ) && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'pp_theme_assets' );

/**
 * Faster font loading.
 *
 * @param array  $urls Hints.
 * @param string $type Relation type.
 * @return array
 */
function pp_theme_resource_hints( $urls, $type ) {
	if ( 'preconnect' === $type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'pp_theme_resource_hints', 10, 2 );

/**
 * The PDF reader is an ES module.
 *
 * @param string $tag    Script tag.
 * @param string $handle Handle.
 * @return string
 */
function pp_theme_module_script( $tag, $handle ) {
	if ( 'pp-pdf-viewer' === $handle ) {
		$tag = str_replace( '<script ', '<script type="module" ', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'pp_theme_module_script', 10, 2 );

/**
 * Default favicon until one is set in Appearance → Customize → Site Identity.
 */
function pp_theme_favicon() {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() . '/assets/images/favicon.ico' ) . '" type="image/x-icon">' . "\n";
	}
}
add_action( 'wp_head', 'pp_theme_favicon' );

/**
 * "Title | Pariksha Path".
 *
 * @return string
 */
function pp_theme_title_separator() {
	return '|';
}
add_filter( 'document_title_separator', 'pp_theme_title_separator' );

/**
 * Button styles for the block editor (same as the site's buttons).
 */
function pp_theme_block_styles() {
	register_block_style(
		'core/button',
		array(
			'name'  => 'marigold',
			'label' => __( 'Marigold', 'pariksha-path' ),
		)
	);
	register_block_style(
		'core/button',
		array(
			'name'  => 'ink',
			'label' => __( 'Ink green', 'pariksha-path' ),
		)
	);
}
add_action( 'init', 'pp_theme_block_styles' );

/**
 * Shorter excerpts on cards.
 *
 * @return int
 */
function pp_theme_excerpt_length() {
	return 28;
}
add_filter( 'excerpt_length', 'pp_theme_excerpt_length' );

/**
 * Plain "…" after excerpts.
 *
 * @return string
 */
function pp_theme_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'pp_theme_excerpt_more' );

/**
 * Remind the admin to activate the companion plugin.
 */
function pp_theme_plugin_notice() {
	if ( function_exists( 'pp_get_exams' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . esc_html__( 'Pariksha Path theme: please install and activate the "Pariksha Path Core" plugin to show your notes and exam sections.', 'pariksha-path' ) . '</p></div>';
}
add_action( 'admin_notices', 'pp_theme_plugin_notice' );
