<?php
/**
 * Plugin Name:       Pariksha Path Core
 * Plugin URI:        https://exampath-shamim.lovable.app
 * Description:       Notes, exam and subject sections, PDF uploads and a one-click importer for the Pariksha Path website. Works with the Pariksha Path theme.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Shamim Ahmad
 * License:           GPL-2.0-or-later
 * Text Domain:       pariksha-path
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

define( 'PP_CORE_VERSION', '1.0.0' );
define( 'PP_CORE_FILE', __FILE__ );
define( 'PP_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'PP_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once PP_CORE_DIR . 'includes/helpers.php';
require_once PP_CORE_DIR . 'includes/post-types.php';
require_once PP_CORE_DIR . 'includes/term-meta.php';
require_once PP_CORE_DIR . 'includes/note-meta.php';
require_once PP_CORE_DIR . 'includes/seed.php';
require_once PP_CORE_DIR . 'includes/importer.php';

/**
 * Activation: register types, create the exam sections, refresh permalinks.
 */
function pp_core_activate() {
	pp_core_register_types();
	pp_core_seed_exams();
	// Only the site owner adds notes: keep public registration switched off.
	update_option( 'users_can_register', 0 );
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'pp_core_activate' );

/**
 * Deactivation: drop our permalink rules.
 */
function pp_core_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'pp_core_deactivate' );
