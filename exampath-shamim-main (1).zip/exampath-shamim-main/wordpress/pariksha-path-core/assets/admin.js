/* Media picker for the note "PDF file" box. */
(function ($) {
  var frame;
  $('#pp_pdf_pick').on('click', function (e) {
    e.preventDefault();
    if (!frame) {
      frame = wp.media({
        title: 'Choose a PDF',
        button: { text: 'Use this PDF' },
        library: { type: 'application/pdf' },
        multiple: false,
      });
      frame.on('select', function () {
        var file = frame.state().get('selection').first().toJSON();
        if (file.mime !== 'application/pdf') {
          window.alert('Only PDF files can be used.');
          return;
        }
        $('#pp_pdf_id').val(file.id);
        $('#pp_pdf_name').text(file.filename);
        $('#pp_pdf_clear').show();
      });
    }
    frame.open();
  });
  $('#pp_pdf_clear').on('click', function (e) {
    e.preventDefault();
    $('#pp_pdf_id').val('');
    $('#pp_pdf_name').text('');
    $(this).hide();
  });
})(jQuery);
