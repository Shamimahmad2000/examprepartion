/* Imports the bundled notes one by one. */
(function () {
  var btn = document.getElementById('pp-import-start');
  if (!btn || !window.ppImport) return;
  var statusEl = document.getElementById('pp-import-status');
  var bar = document.getElementById('pp-import-bar');
  var log = document.getElementById('pp-import-log');
  var labels = { copied: 'PDF copied', linked: 'linked to old site', skipped: 'already imported' };

  function add(text, isError) {
    var li = document.createElement('li');
    li.textContent = text;
    if (isError) li.style.color = '#b32d2e';
    log.appendChild(li);
    log.scrollTop = log.scrollHeight;
  }

  async function run() {
    btn.disabled = true;
    bar.style.display = 'block';
    var copy = document.getElementById('pp-import-copy').checked ? '1' : '0';
    var errors = 0;
    for (var i = 0; i < ppImport.total; i++) {
      statusEl.textContent = 'Importing ' + (i + 1) + ' of ' + ppImport.total + '…';
      var body = new URLSearchParams({ action: 'pp_import_one', nonce: ppImport.nonce, index: String(i), copy: copy });
      try {
        var res = await fetch(ppImport.ajax, { method: 'POST', credentials: 'same-origin', body: body });
        var json = await res.json();
        if (json.success) add(json.data.title + ' — ' + (labels[json.data.status] || json.data.status));
        else { errors++; add('Note ' + (i + 1) + ': ' + ((json.data && json.data.message) || 'failed'), true); }
      } catch (e) {
        errors++;
        add('Note ' + (i + 1) + ': ' + e.message, true);
      }
      bar.value = i + 1;
    }
    statusEl.textContent = errors ? 'Finished with ' + errors + ' problem(s). Press the button again to retry them.' : 'All done! Your notes are on the site.';
    btn.disabled = false;
  }
  btn.addEventListener('click', run);
})();
