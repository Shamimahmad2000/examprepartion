<?php
/**
 * Default exam and subject sections (same as the Lovable site).
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'slug'     => 'ctet',
		'short'    => 'CTET',
		'name'     => 'Central Teacher Eligibility Test',
		'hindi'    => 'केंद्रीय शिक्षक पात्रता परीक्षा',
		'blurb'    => 'Paper 1 & Paper 2 notes, MCQs and pedagogy sets for every CTET subject.',
		'subjects' => array(
			array( 'cdp', 'Child Development & Pedagogy', 'बाल विकास एवं शिक्षाशास्त्र' ),
			array( 'sst', 'Social Studies (SST)', 'सामाजिक अध्ययन' ),
			array( 'geography', 'Geography (SST)', 'भूगोल' ),
			array( 'maths', 'Mathematics', 'गणित' ),
			array( 'science', 'Science', 'विज्ञान' ),
			array( 'evs', 'Environmental Studies (EVS)', 'पर्यावरण अध्ययन' ),
			array( 'hindi', 'Hindi Language', 'हिंदी भाषा' ),
			array( 'english', 'English Language', 'अंग्रेज़ी भाषा' ),
			array( 'urdu', 'Urdu Language', 'उर्दू भाषा' ),
			array( 'sanskrit', 'Sanskrit Language', 'संस्कृत भाषा' ),
		),
	),
	array(
		'slug'     => 'stet',
		'short'    => 'STET',
		'name'     => 'State Teacher Eligibility Test',
		'hindi'    => 'राज्य शिक्षक पात्रता परीक्षा',
		'blurb'    => 'Bihar STET and other state TET subject notes for secondary & senior secondary.',
		'subjects' => array(
			array( 'sst', 'Social Science', 'सामाजिक विज्ञान' ),
			array( 'maths', 'Mathematics', 'गणित' ),
			array( 'science', 'Science', 'विज्ञान' ),
			array( 'hindi', 'Hindi', 'हिंदी' ),
			array( 'english', 'English', 'अंग्रेज़ी' ),
			array( 'urdu', 'Urdu', 'उर्दू' ),
			array( 'sanskrit', 'Sanskrit', 'संस्कृत' ),
			array( 'computer', 'Computer Science', 'कंप्यूटर विज्ञान' ),
		),
	),
	array(
		'slug'     => 'bpsc-tre',
		'short'    => 'BPSC TRE',
		'name'     => 'BPSC Teacher Recruitment Exam',
		'hindi'    => 'बीपीएससी शिक्षक भर्ती परीक्षा',
		'blurb'    => 'Notes for BPSC TRE classes 1–5, 6–8, 9–10 and 11–12 including GS and language.',
		'subjects' => array(
			array( 'general-studies', 'General Studies', 'सामान्य अध्ययन' ),
			array( 'language', 'Language (Hindi / English)', 'भाषा' ),
			array( 'cdp', 'Child Development & Pedagogy', 'बाल विकास एवं शिक्षाशास्त्र' ),
			array( 'sst', 'Social Science', 'सामाजिक विज्ञान' ),
			array( 'maths', 'Mathematics', 'गणित' ),
			array( 'science', 'Science', 'विज्ञान' ),
		),
	),
	array(
		'slug'     => 'bpsc',
		'short'    => 'BPSC',
		'name'     => 'Bihar Public Service Commission (CCE)',
		'hindi'    => 'बिहार लोक सेवा आयोग',
		'blurb'    => 'Prelims & Mains notes — History, Polity, Geography, Economy and Bihar special.',
		'subjects' => array(
			array( 'history', 'History', 'इतिहास' ),
			array( 'polity', 'Indian Polity', 'भारतीय राजव्यवस्था' ),
			array( 'geography', 'Geography', 'भूगोल' ),
			array( 'economy', 'Economy', 'अर्थव्यवस्था' ),
			array( 'bihar-gk', 'Bihar Special GK', 'बिहार विशेष' ),
			array( 'current-affairs', 'Current Affairs', 'समसामयिकी' ),
			array( 'science', 'General Science', 'सामान्य विज्ञान' ),
		),
	),
	array(
		'slug'     => 'ssc',
		'short'    => 'SSC',
		'name'     => 'Staff Selection Commission',
		'hindi'    => 'कर्मचारी चयन आयोग',
		'blurb'    => 'CGL, CHSL, MTS and GD notes for maths, reasoning, English and GK.',
		'subjects' => array(
			array( 'maths', 'Quantitative Aptitude', 'गणित' ),
			array( 'reasoning', 'Reasoning', 'तर्कशक्ति' ),
			array( 'english', 'English', 'अंग्रेज़ी' ),
			array( 'gk', 'General Awareness', 'सामान्य ज्ञान' ),
		),
	),
	array(
		'slug'     => 'railway',
		'short'    => 'Railway',
		'name'     => 'Railway Exams (NTPC / Group D)',
		'hindi'    => 'रेलवे परीक्षा',
		'blurb'    => 'RRB NTPC, Group D and ALP notes with previous year questions.',
		'subjects' => array(
			array( 'maths', 'Mathematics', 'गणित' ),
			array( 'reasoning', 'Reasoning', 'तर्कशक्ति' ),
			array( 'gk', 'General Awareness', 'सामान्य ज्ञान' ),
			array( 'science', 'General Science', 'सामान्य विज्ञान' ),
		),
	),
);
