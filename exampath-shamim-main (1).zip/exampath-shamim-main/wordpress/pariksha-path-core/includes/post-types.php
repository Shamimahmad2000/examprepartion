<?php
/**
 * Notes post type and the Exam / Subject sections taxonomy.
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the "Notes" post type and "Exams & Subjects" taxonomy.
 */
function pp_core_register_types() {
	register_post_type(
		'pp_note',
		array(
			'labels'        => array(
				'name'               => __( 'Notes', 'pariksha-path' ),
				'singular_name'      => __( 'Note', 'pariksha-path' ),
				'add_new'            => __( 'Upload note', 'pariksha-path' ),
				'add_new_item'       => __( 'Upload a new note', 'pariksha-path' ),
				'edit_item'          => __( 'Edit note', 'pariksha-path' ),
				'all_items'          => __( 'All notes', 'pariksha-path' ),
				'search_items'       => __( 'Search notes', 'pariksha-path' ),
				'not_found'          => __( 'No notes found.', 'pariksha-path' ),
				'menu_name'          => __( 'Notes', 'pariksha-path' ),
				'view_item'          => __( 'View note', 'pariksha-path' ),
				'featured_image'     => __( 'Cover image', 'pariksha-path' ),
				'item_published'     => __( 'Note published.', 'pariksha-path' ),
			),
			'public'        => true,
			'has_archive'   => 'notes',
			'rewrite'       => array(
				'slug'       => 'notes',
				'with_front' => false,
			),
			'menu_icon'     => 'dashicons-media-document',
			'menu_position' => 5,
			'supports'      => array( 'title', 'excerpt', 'editor', 'thumbnail', 'revisions' ),
			'show_in_rest'  => true,
			'taxonomies'    => array( 'pp_exam' ),
		)
	);

	register_taxonomy(
		'pp_exam',
		array( 'pp_note' ),
		array(
			'labels'            => array(
				'name'          => __( 'Exams & Subjects', 'pariksha-path' ),
				'singular_name' => __( 'Exam / Subject', 'pariksha-path' ),
				'menu_name'     => __( 'Exams & Subjects', 'pariksha-path' ),
				'all_items'     => __( 'All exams & subjects', 'pariksha-path' ),
				'parent_item'   => __( 'Exam (leave empty for a new exam)', 'pariksha-path' ),
				'add_new_item'  => __( 'Add exam or subject', 'pariksha-path' ),
				'edit_item'     => __( 'Edit exam or subject', 'pariksha-path' ),
			),
			'hierarchical'      => true,
			'public'            => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array(
				'slug'         => 'exams',
				'with_front'   => false,
				'hierarchical' => true,
			),
		)
	);

	$meta = array(
		'_pp_pdf_id'    => 'integer',
		'_pp_pdf_url'   => 'string',
		'_pp_language'  => 'string',
		'_pp_pages'     => 'integer',
		'_pp_file_size' => 'integer',
	);
	foreach ( $meta as $key => $type ) {
		register_post_meta(
			'pp_note',
			$key,
			array(
				'type'          => $type,
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}
}
add_action( 'init', 'pp_core_register_types' );

/**
 * Show all notes of a section on one page, newest first (same as the original site).
 *
 * @param WP_Query $query Main query.
 */
function pp_core_note_queries( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->is_post_type_archive( 'pp_note' ) || $query->is_tax( 'pp_exam' ) ) {
		$query->set( 'posts_per_page', 200 );
		$query->set( 'orderby', 'date' );
		$query->set( 'order', 'DESC' );
		$exam = isset( $_GET['exam'] ) ? sanitize_title( wp_unslash( $_GET['exam'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $exam && $query->is_post_type_archive( 'pp_note' ) ) {
			$query->set(
				'tax_query',
				array(
					array(
						'taxonomy'         => 'pp_exam',
						'field'            => 'slug',
						'terms'            => $exam,
						'include_children' => true,
					),
				)
			);
		}
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' !== $q && $query->is_post_type_archive( 'pp_note' ) ) {
			$query->set( 's', $q );
		}
	}
}
add_action( 'pre_get_posts', 'pp_core_note_queries' );

/**
 * Keep the notes archive template when the "q" search is used.
 *
 * @param WP_Query $query Main query.
 */
function pp_core_keep_archive( $query ) {
	if ( ! is_admin() && $query->is_main_query() && $query->is_post_type_archive( 'pp_note' ) ) {
		$query->is_search = false;
	}
}
add_action( 'parse_query', 'pp_core_keep_archive', 99 );

/**
 * Filter notes by exam in the dashboard list.
 *
 * @param string $post_type Current post type.
 */
function pp_core_admin_filter( $post_type ) {
	if ( 'pp_note' !== $post_type ) {
		return;
	}
	wp_dropdown_categories(
		array(
			'taxonomy'        => 'pp_exam',
			'name'            => 'pp_exam',
			'value_field'     => 'slug',
			'show_option_all' => __( 'All exams & subjects', 'pariksha-path' ),
			'hierarchical'    => true,
			'hide_empty'      => false,
			'selected'        => isset( $_GET['pp_exam'] ) ? sanitize_title( wp_unslash( $_GET['pp_exam'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		)
	);
}
add_action( 'restrict_manage_posts', 'pp_core_admin_filter' );

/**
 * Extra columns in the dashboard notes list.
 *
 * @param array $cols Columns.
 * @return array
 */
function pp_core_columns( $cols ) {
	$cols['pp_file'] = __( 'PDF', 'pariksha-path' );
	return $cols;
}
add_filter( 'manage_pp_note_posts_columns', 'pp_core_columns' );

/**
 * Render the PDF column.
 *
 * @param string $col     Column.
 * @param int    $post_id Note ID.
 */
function pp_core_column_value( $col, $post_id ) {
	if ( 'pp_file' !== $col ) {
		return;
	}
	$url = pp_note_file_url( $post_id );
	if ( ! $url ) {
		echo '<span style="color:#b32d2e">' . esc_html__( 'Missing', 'pariksha-path' ) . '</span>';
		return;
	}
	echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( pp_note_meta_line( $post_id ) ?: __( 'Open', 'pariksha-path' ) ) . '</a>';
}
add_action( 'manage_pp_note_posts_custom_column', 'pp_core_column_value', 10, 2 );
