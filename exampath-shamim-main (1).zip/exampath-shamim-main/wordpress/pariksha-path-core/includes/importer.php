<?php
/**
 * One-click import of the notes from the original Lovable website.
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Bundled notes list.
 *
 * @return array
 */
function pp_import_items() {
	$json = file_get_contents( PP_CORE_DIR . 'data/notes.json' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	$data = json_decode( (string) $json, true );
	return is_array( $data ) ? $data : array();
}

/**
 * Already imported note for an original note ID.
 *
 * @param string $source_id Original ID.
 * @return int
 */
function pp_import_existing( $source_id ) {
	$found = get_posts(
		array(
			'post_type'      => 'pp_note',
			'post_status'    => 'any',
			'meta_key'       => '_pp_source_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => $source_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'fields'         => 'ids',
			'posts_per_page' => 1,
		)
	);
	return $found ? (int) $found[0] : 0;
}

/**
 * Admin page under Notes.
 */
function pp_import_menu() {
	add_submenu_page( 'edit.php?post_type=pp_note', __( 'Import notes', 'pariksha-path' ), __( 'Import notes', 'pariksha-path' ), 'manage_options', 'pp-import', 'pp_import_page' );
}
add_action( 'admin_menu', 'pp_import_menu' );

/**
 * Render the importer page.
 */
function pp_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$items = pp_import_items();
	$done  = 0;
	foreach ( $items as $item ) {
		if ( pp_import_existing( $item['source_id'] ) ) {
			++$done;
		}
	}
	wp_enqueue_script( 'pp-import', PP_CORE_URL . 'assets/import.js', array(), PP_CORE_VERSION, true );
	wp_localize_script(
		'pp-import',
		'ppImport',
		array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'pp_import' ),
			'total' => count( $items ),
		)
	);
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Import notes from the old Pariksha Path website', 'pariksha-path' ); ?></h1>
		<p>
			<?php
			printf(
				/* translators: 1: total notes, 2: already imported */
				esc_html__( 'This copies all %1$d notes (CTET CDP, SST and Geography) into WordPress, with their titles, descriptions, sections and PDF files. Already imported: %2$d.', 'pariksha-path' ),
				(int) count( $items ),
				(int) $done
			);
			?>
		</p>
		<p><label><input type="checkbox" id="pp-import-copy" checked> <?php esc_html_e( 'Copy each PDF into my Media Library (recommended — about 160 MB in total). Untick to keep linking to the old website.', 'pariksha-path' ); ?></label></p>
		<p><button type="button" class="button button-primary button-hero" id="pp-import-start"><?php esc_html_e( 'Start import', 'pariksha-path' ); ?></button></p>
		<p id="pp-import-status" aria-live="polite"></p>
		<progress id="pp-import-bar" max="<?php echo esc_attr( (string) count( $items ) ); ?>" value="0" style="width:100%;max-width:520px;display:none"></progress>
		<ol id="pp-import-log" style="max-height:320px;overflow:auto"></ol>
		<p class="description"><?php esc_html_e( 'You can close this page and start again later — notes that were already imported are skipped.', 'pariksha-path' ); ?></p>
	</div>
	<?php
}

/**
 * Import one note (AJAX, one at a time so large PDFs don't time out).
 */
function pp_import_one() {
	check_ajax_referer( 'pp_import', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'Not allowed.', 'pariksha-path' ) ), 403 );
	}
	$index = isset( $_POST['index'] ) ? absint( $_POST['index'] ) : 0;
	$copy  = ! empty( $_POST['copy'] ) && '1' === $_POST['copy'];
	$items = pp_import_items();
	if ( ! isset( $items[ $index ] ) ) {
		wp_send_json_error( array( 'message' => __( 'Unknown note.', 'pariksha-path' ) ), 400 );
	}
	$item = $items[ $index ];

	$existing = pp_import_existing( $item['source_id'] );
	if ( $existing ) {
		wp_send_json_success(
			array(
				'title'  => $item['title'],
				'status' => 'skipped',
			)
		);
	}

	$term = get_term_by( 'slug', pp_subject_term_slug( $item['exam'], $item['subject'] ), 'pp_exam' );
	if ( ! $term ) {
		$term = get_term_by( 'slug', $item['exam'], 'pp_exam' );
	}

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'pp_note',
			'post_status'  => ! empty( $item['published'] ) ? 'publish' : 'draft',
			'post_title'   => sanitize_text_field( $item['title'] ),
			'post_excerpt' => sanitize_textarea_field( $item['description'] ),
			'post_date'    => get_date_from_gmt( $item['date'] ),
		),
		true
	);
	if ( is_wp_error( $post_id ) ) {
		wp_send_json_error( array( 'message' => $post_id->get_error_message() ), 500 );
	}
	if ( $term ) {
		wp_set_object_terms( $post_id, array( (int) $term->term_id ), 'pp_exam' );
	}
	update_post_meta( $post_id, '_pp_source_id', sanitize_text_field( $item['source_id'] ) );
	update_post_meta( $post_id, '_pp_language', sanitize_text_field( $item['language'] ) );
	update_post_meta( $post_id, '_pp_pages', absint( $item['pages'] ) );
	update_post_meta( $post_id, '_pp_file_size', absint( $item['file_size'] ) );

	$url    = esc_url_raw( $item['url'] );
	$status = 'linked';
	if ( $copy ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		$tmp = download_url( $url, 300 );
		if ( ! is_wp_error( $tmp ) ) {
			$att = media_handle_sideload(
				array(
					'name'     => sanitize_file_name( basename( wp_parse_url( $url, PHP_URL_PATH ) ) ),
					'tmp_name' => $tmp,
				),
				$post_id,
				$item['title']
			);
			if ( ! is_wp_error( $att ) ) {
				update_post_meta( $post_id, '_pp_pdf_id', (int) $att );
				$status = 'copied';
			} else {
				wp_delete_file( $tmp );
			}
		}
	}
	if ( 'copied' !== $status ) {
		update_post_meta( $post_id, '_pp_pdf_url', $url );
	}

	wp_send_json_success(
		array(
			'title'  => $item['title'],
			'status' => $status,
		)
	);
}
add_action( 'wp_ajax_pp_import_one', 'pp_import_one' );
