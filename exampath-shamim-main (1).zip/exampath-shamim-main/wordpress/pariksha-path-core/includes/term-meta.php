<?php
/**
 * Extra fields on exams & subjects: full name, Hindi name, display order.
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Fields on the "Add exam or subject" form.
 */
function pp_term_add_fields() {
	wp_nonce_field( 'pp_term_meta', 'pp_term_meta_nonce' );
	?>
	<div class="form-field">
		<label for="pp_full_name"><?php esc_html_e( 'Full name (exams only)', 'pariksha-path' ); ?></label>
		<input type="text" name="pp_full_name" id="pp_full_name" value="">
		<p><?php esc_html_e( 'Example: Central Teacher Eligibility Test', 'pariksha-path' ); ?></p>
	</div>
	<div class="form-field">
		<label for="pp_hindi"><?php esc_html_e( 'Hindi name', 'pariksha-path' ); ?></label>
		<input type="text" name="pp_hindi" id="pp_hindi" value="">
	</div>
	<div class="form-field">
		<label for="pp_order"><?php esc_html_e( 'Display order', 'pariksha-path' ); ?></label>
		<input type="number" name="pp_order" id="pp_order" value="0" min="0" step="1">
	</div>
	<?php
}
add_action( 'pp_exam_add_form_fields', 'pp_term_add_fields' );

/**
 * Fields on the "Edit exam or subject" form.
 *
 * @param WP_Term $term Term.
 */
function pp_term_edit_fields( $term ) {
	wp_nonce_field( 'pp_term_meta', 'pp_term_meta_nonce' );
	$fields = array(
		'pp_full_name' => __( 'Full name (exams only)', 'pariksha-path' ),
		'pp_hindi'     => __( 'Hindi name', 'pariksha-path' ),
		'pp_order'     => __( 'Display order', 'pariksha-path' ),
	);
	foreach ( $fields as $key => $label ) {
		$value = get_term_meta( $term->term_id, $key, true );
		?>
		<tr class="form-field">
			<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td><input type="<?php echo 'pp_order' === $key ? 'number' : 'text'; ?>" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>"></td>
		</tr>
		<?php
	}
}
add_action( 'pp_exam_edit_form_fields', 'pp_term_edit_fields' );

/**
 * Save the extra fields.
 *
 * @param int $term_id Term ID.
 */
function pp_term_save_fields( $term_id ) {
	if ( ! isset( $_POST['pp_term_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['pp_term_meta_nonce'] ), 'pp_term_meta' ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_categories' ) ) {
		return;
	}
	if ( isset( $_POST['pp_full_name'] ) ) {
		update_term_meta( $term_id, 'pp_full_name', sanitize_text_field( wp_unslash( $_POST['pp_full_name'] ) ) );
	}
	if ( isset( $_POST['pp_hindi'] ) ) {
		update_term_meta( $term_id, 'pp_hindi', sanitize_text_field( wp_unslash( $_POST['pp_hindi'] ) ) );
	}
	if ( isset( $_POST['pp_order'] ) ) {
		update_term_meta( $term_id, 'pp_order', absint( $_POST['pp_order'] ) );
	}
}
add_action( 'created_pp_exam', 'pp_term_save_fields' );
add_action( 'edited_pp_exam', 'pp_term_save_fields' );
