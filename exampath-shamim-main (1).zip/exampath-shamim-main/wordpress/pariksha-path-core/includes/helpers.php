<?php
/**
 * Helper functions shared with the theme.
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Human readable file size, e.g. "1.2 MB".
 *
 * @param int $bytes Size in bytes.
 * @return string
 */
function pp_format_bytes( $bytes ) {
	$bytes = (int) $bytes;
	if ( $bytes <= 0 ) {
		return '';
	}
	if ( $bytes < 1024 * 1024 ) {
		return round( $bytes / 1024 ) . ' KB';
	}
	return number_format( $bytes / ( 1024 * 1024 ), 1 ) . ' MB';
}

/**
 * Sort terms by their "order" meta, then by name.
 *
 * @param WP_Term[] $terms Terms.
 * @return WP_Term[]
 */
function pp_sort_terms( $terms ) {
	if ( ! is_array( $terms ) ) {
		return array();
	}
	usort(
		$terms,
		function ( $a, $b ) {
			$oa = (int) get_term_meta( $a->term_id, 'pp_order', true );
			$ob = (int) get_term_meta( $b->term_id, 'pp_order', true );
			if ( $oa === $ob ) {
				return strcmp( $a->name, $b->name );
			}
			return $oa - $ob;
		}
	);
	return $terms;
}

/**
 * All exams (top-level sections), in display order.
 *
 * @return WP_Term[]
 */
function pp_get_exams() {
	$terms = get_terms(
		array(
			'taxonomy'   => 'pp_exam',
			'parent'     => 0,
			'hide_empty' => false,
		)
	);
	return is_wp_error( $terms ) ? array() : pp_sort_terms( $terms );
}

/**
 * Subjects of one exam, in display order.
 *
 * @param WP_Term|int $exam Exam term.
 * @return WP_Term[]
 */
function pp_get_subjects( $exam ) {
	$exam_id = $exam instanceof WP_Term ? $exam->term_id : (int) $exam;
	$terms   = get_terms(
		array(
			'taxonomy'   => 'pp_exam',
			'parent'     => $exam_id,
			'hide_empty' => false,
		)
	);
	return is_wp_error( $terms ) ? array() : pp_sort_terms( $terms );
}

/**
 * Number of published notes in a section, including its subjects.
 *
 * @param WP_Term $term Exam or subject term.
 * @return int
 */
function pp_term_note_count( $term ) {
	$q = new WP_Query(
		array(
			'post_type'      => 'pp_note',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => false,
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy'         => 'pp_exam',
					'terms'            => $term->term_id,
					'include_children' => true,
				),
			),
		)
	);
	return (int) $q->found_posts;
}

/**
 * Hindi name of an exam or subject term.
 *
 * @param WP_Term $term Term.
 * @return string
 */
function pp_term_hindi( $term ) {
	return (string) get_term_meta( $term->term_id, 'pp_hindi', true );
}

/**
 * Full name of an exam term, e.g. "Central Teacher Eligibility Test".
 *
 * @param WP_Term $term Term.
 * @return string
 */
function pp_term_full_name( $term ) {
	$full = (string) get_term_meta( $term->term_id, 'pp_full_name', true );
	return '' !== $full ? $full : $term->name;
}

/**
 * Exam and subject of a note.
 *
 * @param int $post_id Note ID.
 * @return array{exam: ?WP_Term, subject: ?WP_Term}
 */
function pp_note_sections( $post_id ) {
	$out   = array(
		'exam'    => null,
		'subject' => null,
	);
	$terms = get_the_terms( $post_id, 'pp_exam' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return $out;
	}
	foreach ( $terms as $t ) {
		if ( $t->parent ) {
			$out['subject'] = $t;
			$out['exam']    = get_term( $t->parent, 'pp_exam' );
			return $out;
		}
	}
	$out['exam'] = $terms[0];
	return $out;
}

/**
 * Public URL of a note's PDF (media library file or a pasted link).
 *
 * @param int $post_id Note ID.
 * @return string
 */
function pp_note_file_url( $post_id ) {
	$att = (int) get_post_meta( $post_id, '_pp_pdf_id', true );
	if ( $att ) {
		$url = wp_get_attachment_url( $att );
		if ( $url ) {
			return $url;
		}
	}
	return (string) get_post_meta( $post_id, '_pp_pdf_url', true );
}

/**
 * "244 pages · 20.6 MB · Hindi + English".
 *
 * @param int $post_id Note ID.
 * @return string
 */
function pp_note_meta_line( $post_id ) {
	$pages = (int) get_post_meta( $post_id, '_pp_pages', true );
	$parts = array_filter(
		array(
			$pages ? sprintf( /* translators: %d: number of pages */ _n( '%d page', '%d pages', $pages, 'pariksha-path' ), $pages ) : '',
			pp_format_bytes( (int) get_post_meta( $post_id, '_pp_file_size', true ) ),
			(string) get_post_meta( $post_id, '_pp_language', true ),
		)
	);
	return implode( ' · ', $parts );
}
