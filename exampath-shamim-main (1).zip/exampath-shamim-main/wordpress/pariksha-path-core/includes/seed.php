<?php
/**
 * Creates the default exam and subject sections once.
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Slug of a subject term. Subjects repeat across exams (e.g. "sst"),
 * so the exam is put in front: "ctet-sst".
 *
 * @param string $exam    Exam slug.
 * @param string $subject Subject slug.
 * @return string
 */
function pp_subject_term_slug( $exam, $subject ) {
	return $exam . '-' . $subject;
}

/**
 * Insert the default exams and subjects when they don't exist yet.
 */
function pp_core_seed_exams() {
	$exams = require PP_CORE_DIR . 'data/exams.php';
	foreach ( $exams as $i => $exam ) {
		$found = get_term_by( 'slug', $exam['slug'], 'pp_exam' );
		if ( $found ) {
			$exam_id = $found->term_id;
		} else {
			$res = wp_insert_term(
				$exam['short'],
				'pp_exam',
				array(
					'slug'        => $exam['slug'],
					'description' => $exam['blurb'],
				)
			);
			if ( is_wp_error( $res ) ) {
				continue;
			}
			$exam_id = $res['term_id'];
			update_term_meta( $exam_id, 'pp_full_name', $exam['name'] );
			update_term_meta( $exam_id, 'pp_hindi', $exam['hindi'] );
			update_term_meta( $exam_id, 'pp_order', $i + 1 );
		}
		foreach ( $exam['subjects'] as $j => $subject ) {
			$slug = pp_subject_term_slug( $exam['slug'], $subject[0] );
			if ( get_term_by( 'slug', $slug, 'pp_exam' ) ) {
				continue;
			}
			$res = wp_insert_term(
				$subject[1],
				'pp_exam',
				array(
					'slug'   => $slug,
					'parent' => $exam_id,
				)
			);
			if ( ! is_wp_error( $res ) ) {
				update_term_meta( $res['term_id'], 'pp_hindi', $subject[2] );
				update_term_meta( $res['term_id'], 'pp_order', $j + 1 );
			}
		}
	}
	update_option( 'pp_core_seeded', PP_CORE_VERSION );
}

/**
 * Safety net: seed on first load if activation didn't run (e.g. files copied by FTP).
 */
function pp_core_maybe_seed() {
	if ( ! get_option( 'pp_core_seeded' ) ) {
		pp_core_seed_exams();
		flush_rewrite_rules();
	}
}
add_action( 'init', 'pp_core_maybe_seed', 20 );
