<?php
/**
 * "PDF file" box on the note editor: pick/upload the PDF, language and pages.
 *
 * @package Pariksha_Path_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the box.
 */
function pp_note_add_box() {
	add_meta_box( 'pp_note_file', __( 'PDF file', 'pariksha-path' ), 'pp_note_box_html', 'pp_note', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'pp_note_add_box' );

/**
 * Load the media picker on the note editor.
 *
 * @param string $hook Admin page.
 */
function pp_note_admin_assets( $hook ) {
	$screen = get_current_screen();
	if ( ! $screen || 'pp_note' !== $screen->post_type ) {
		return;
	}
	if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
		wp_enqueue_media();
		wp_enqueue_script( 'pp-note-admin', PP_CORE_URL . 'assets/admin.js', array( 'jquery' ), PP_CORE_VERSION, true );
	}
}
add_action( 'admin_enqueue_scripts', 'pp_note_admin_assets' );

/**
 * Box contents.
 *
 * @param WP_Post $post Note.
 */
function pp_note_box_html( $post ) {
	wp_nonce_field( 'pp_note_save', 'pp_note_nonce' );
	$att      = (int) get_post_meta( $post->ID, '_pp_pdf_id', true );
	$url      = (string) get_post_meta( $post->ID, '_pp_pdf_url', true );
	$language = (string) get_post_meta( $post->ID, '_pp_language', true );
	$pages    = (int) get_post_meta( $post->ID, '_pp_pages', true );
	$name     = $att ? basename( (string) get_attached_file( $att ) ) : '';
	?>
	<p>
		<strong><?php esc_html_e( 'PDF', 'pariksha-path' ); ?></strong><br>
		<input type="hidden" name="pp_pdf_id" id="pp_pdf_id" value="<?php echo esc_attr( $att ?: '' ); ?>">
		<button type="button" class="button button-primary" id="pp_pdf_pick"><?php esc_html_e( 'Upload or choose PDF', 'pariksha-path' ); ?></button>
		<button type="button" class="button" id="pp_pdf_clear" <?php echo $att ? '' : 'style="display:none"'; ?>><?php esc_html_e( 'Remove', 'pariksha-path' ); ?></button>
		<span id="pp_pdf_name" style="margin-left:8px"><?php echo esc_html( $name ); ?></span>
	</p>
	<p>
		<label for="pp_pdf_url"><?php esc_html_e( 'Or paste a link to the PDF (used only when no file is chosen above)', 'pariksha-path' ); ?></label><br>
		<input type="url" class="widefat" name="pp_pdf_url" id="pp_pdf_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://">
	</p>
	<p style="display:flex;gap:16px;flex-wrap:wrap">
		<label><?php esc_html_e( 'Language', 'pariksha-path' ); ?><br>
			<input type="text" name="pp_language" list="pp_languages" value="<?php echo esc_attr( $language ); ?>">
			<datalist id="pp_languages"><option value="Hindi + English"><option value="Hindi"><option value="English"><option value="Urdu"></datalist>
		</label>
		<label><?php esc_html_e( 'Number of pages', 'pariksha-path' ); ?><br>
			<input type="number" min="0" name="pp_pages" value="<?php echo esc_attr( $pages ?: '' ); ?>">
		</label>
	</p>
	<p class="description"><?php esc_html_e( 'Pick the subject on the right under "Exams & Subjects". The short description goes in "Excerpt". Only PDF files are accepted.', 'pariksha-path' ); ?></p>
	<?php
}

/**
 * Try to count pages of a local PDF (works for most simple PDFs).
 *
 * @param string $file Path.
 * @return int
 */
function pp_count_pdf_pages( $file ) {
	if ( ! $file || ! is_readable( $file ) || filesize( $file ) > 80 * 1024 * 1024 ) {
		return 0;
	}
	$data = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( false === $data ) {
		return 0;
	}
	if ( preg_match_all( '/\/Type\s*\/Page[^s]/', $data, $m ) ) {
		return count( $m[0] );
	}
	return 0;
}

/**
 * Save the box.
 *
 * @param int $post_id Note ID.
 */
function pp_note_save( $post_id ) {
	if ( ! isset( $_POST['pp_note_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['pp_note_nonce'] ), 'pp_note_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$att = isset( $_POST['pp_pdf_id'] ) ? absint( $_POST['pp_pdf_id'] ) : 0;
	if ( $att && 'application/pdf' !== get_post_mime_type( $att ) ) {
		$att = 0; // Only PDFs.
	}
	if ( $att ) {
		update_post_meta( $post_id, '_pp_pdf_id', $att );
		$file = get_attached_file( $att );
		if ( $file && file_exists( $file ) ) {
			update_post_meta( $post_id, '_pp_file_size', (int) filesize( $file ) );
		}
	} else {
		delete_post_meta( $post_id, '_pp_pdf_id' );
	}

	$url = isset( $_POST['pp_pdf_url'] ) ? esc_url_raw( wp_unslash( $_POST['pp_pdf_url'] ), array( 'https', 'http' ) ) : '';
	if ( $url ) {
		update_post_meta( $post_id, '_pp_pdf_url', $url );
	} else {
		delete_post_meta( $post_id, '_pp_pdf_url' );
	}

	$language = isset( $_POST['pp_language'] ) ? sanitize_text_field( wp_unslash( $_POST['pp_language'] ) ) : '';
	update_post_meta( $post_id, '_pp_language', $language );

	$pages = isset( $_POST['pp_pages'] ) ? absint( $_POST['pp_pages'] ) : 0;
	if ( ! $pages && $att ) {
		$pages = pp_count_pdf_pages( get_attached_file( $att ) );
	}
	if ( $pages ) {
		update_post_meta( $post_id, '_pp_pages', $pages );
	} else {
		delete_post_meta( $post_id, '_pp_pages' );
	}
}
add_action( 'save_post_pp_note', 'pp_note_save' );
