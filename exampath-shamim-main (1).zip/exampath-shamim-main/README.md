# Exampath Shamim

Make a website for compatitive exam preparation like Ctet Stet BPCS or other and make section for notes upload and upload given notes in ctet SST section

Run by Shamim Ahmad

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://exampath-shamim.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/18970451-719c-4b18-90bf-75efafa0446e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
